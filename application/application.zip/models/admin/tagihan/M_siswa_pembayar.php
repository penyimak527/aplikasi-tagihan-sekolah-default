<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_siswa_pembayar extends CI_Model
{
    public function tagihan_list(){return $this->db->where_in('status',array('Aktif','Draft'))->order_by('id','DESC')->get('tagihan_master')->result_array();}
    public function result(){
        $id=(int)$this->input->post('id_tagihan');$kelas=(int)$this->input->post('id_kelas_setting');$search=trim((string)$this->input->post('search',true));$m=$this->db->where('id',$id)->get('tagihan_master')->row_array();if(!$m)return array('result'=>'false','message'=>'Pilih tagihan.');$like='%'.$search.'%';
        $current=$this->db->query("SELECT ts.id_siswa,ts.nis,ts.nisn,ts.nama_siswa,ts.id_kelas_setting,ts.nama_kelas,COUNT(*) jumlah_baris,MAX(ts.nominal_tagihan) tarif,COALESCE(SUM(ts.nominal_dibayar),0) dibayar,COALESCE(SUM(ts.sisa_tagihan),0) sisa,MIN(ts.status_tagihan) status_tagihan FROM tagihan_siswa ts WHERE ts.id_tagihan_master=? AND (ts.nama_siswa LIKE ? OR ts.nis LIKE ? OR ts.nisn LIKE ?) ".($kelas?" AND ts.id_kelas_setting=".$kelas:'')." GROUP BY ts.id_siswa,ts.nis,ts.nisn,ts.nama_siswa,ts.id_kelas_setting,ts.nama_kelas ORDER BY ts.nama_siswa",array($id,$like,$like,$like))->result_array();
        $sql="SELECT DISTINCT s.id id_siswa,s.nis,s.nisn,s.nama_lengkap nama_siswa,k.id id_kelas_setting,k.id_kelas,k.nama_kelas FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) WHERE s.status_pendaftaran='Aktif' AND CAST(k.id_periode AS UNSIGNED)=? AND (s.nama_lengkap LIKE ? OR s.nis LIKE ? OR s.nisn LIKE ?) AND NOT EXISTS(SELECT 1 FROM tagihan_siswa t WHERE t.id_tagihan_master=? AND t.id_siswa=s.id)";$params=array((int)$m['id_periode'],$like,$like,$like,$id);if($kelas){$sql.=" AND k.id=?";$params[]=$kelas;}$sql.=" ORDER BY s.nama_lengkap LIMIT 500";$candidates=$this->db->query($sql,$params)->result_array();$classes=$this->db->where('id_tagihan_master',$id)->get('tagihan_target_kelas')->result_array();return array('result'=>'true','master'=>$m,'current'=>$current,'candidates'=>$candidates,'classes'=>$classes);
    }

    public function export_rows($idTagihan, $search = '')
    {
        $idTagihan = (int) $idTagihan;
        $search = trim((string) $search);
        $master = $this->db->where('id', $idTagihan)->get('tagihan_master')->row_array();

        if (!$master) {
            return array('master' => null, 'rows' => array());
        }

        $like = '%' . $search . '%';
        $rows = $this->db->query(
            "SELECT ts.id_siswa, ts.nis, ts.nisn, ts.nama_siswa, ts.nama_kelas,
                    COUNT(*) jumlah_baris,
                    MAX(ts.nominal_tagihan) tarif,
                    COALESCE(SUM(ts.nominal_dibayar),0) dibayar,
                    COALESCE(SUM(ts.sisa_tagihan),0) sisa,
                    MIN(ts.status_tagihan) status_tagihan
             FROM tagihan_siswa ts
             WHERE ts.id_tagihan_master = ?
               AND (ts.nama_siswa LIKE ? OR ts.nis LIKE ? OR ts.nisn LIKE ?)
             GROUP BY ts.id_siswa, ts.nis, ts.nisn, ts.nama_siswa, ts.nama_kelas
             ORDER BY ts.nama_siswa ASC",
            array($idTagihan, $like, $like, $like)
        )->result_array();

        return array('master' => $master, 'rows' => $rows);
    }

    public function tambah(){
        $id=(int)$this->input->post('id_tagihan');$ids=$this->input->post('id_siswa');if(!is_array($ids))$ids=array();$m=$this->db->where('id',$id)->get('tagihan_master')->row_array();if(!$m||!$ids)return model_response(false,'Pilih tagihan dan siswa.');if($m['status']==='Draft')return model_response(false,'Terbitkan draft terlebih dahulu sebelum menambah siswa.');$periods=$this->db->where('id_tagihan_master',$id)->where('status','Aktif')->get('tagihan_tarif_bulan')->result_array();$classes=$this->db->where('id_tagihan_master',$id)->get('tagihan_target_kelas')->result_array();$classMap=array();foreach($classes as $x)$classMap[(int)$x['id_kelas_setting']]=$x;$this->db->trans_begin();$success=0;$skip=0;
        foreach($ids as $sid){$sid=(int)$sid;$s=$this->db->query("SELECT s.*,k.id id_kelas_setting,k.id_kelas,k.nama_kelas,k.id_periode,ta.periode FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) LEFT JOIN master_tahun_ajaran ta ON ta.id=CAST(k.id_periode AS UNSIGNED) WHERE s.id=? AND CAST(k.id_periode AS UNSIGNED)=? ORDER BY ks.id DESC LIMIT 1",array($sid,(int)$m['id_periode']))->row_array();if(!$s){$skip++;continue;}foreach($periods as $p){if($this->db->where('id_tagihan_master',$id)->where('id_siswa',$sid)->where('bulan',$p['bulan'])->where('tahun',$p['tahun'])->count_all_results('tagihan_siswa')){$skip++;continue;}$nom=(float)$p['nominal'];if(isset($classMap[(int)$s['id_kelas_setting']])&&(float)$classMap[(int)$s['id_kelas_setting']]['nominal_kelas']>0)$nom=(float)$classMap[(int)$s['id_kelas_setting']]['nominal_kelas'];$this->db->insert('tagihan_siswa',array('no_tagihan'=>tagihan_next_code('TAG','tagihan_siswa','no_tagihan'),'id_tagihan_master'=>$id,'kode_tagihan'=>$m['kode_tagihan'],'id_jenis_tagihan'=>$m['id_jenis_tagihan'],'nama_jenis_tagihan'=>$m['nama_jenis_tagihan'],'nama_tagihan'=>$m['nama_tagihan'],'tipe_tagihan'=>$m['tipe_tagihan'],'id_periode'=>$m['id_periode'],'periode'=>$m['periode'],'semester'=>null,'bulan'=>$p['bulan'],'nama_bulan'=>$p['nama_bulan'],'tahun'=>$p['tahun'],'tanggal_jatuh_tempo'=>$p['tanggal_jatuh_tempo'],'id_siswa'=>$sid,'nis'=>$s['nis'],'nisn'=>$s['nisn'],'nama_siswa'=>$s['nama_lengkap'],'id_kelas_setting'=>$s['id_kelas_setting'],'id_kelas'=>$s['id_kelas'],'nama_kelas'=>$s['nama_kelas'],'nominal_awal'=>$nom,'nilai_keringanan'=>0,'nominal_tagihan'=>$nom,'nominal_dibayar'=>0,'sisa_tagihan'=>$nom,'dianggap_tunggakan'=>$m['dianggap_tunggakan'],'status_pembayaran'=>'Belum Dibayar','status_tagihan'=>'Aktif','tanggal_generate'=>tanggal_sekarang(),'waktu_generate'=>waktu_sekarang(),'id_user_generate'=>app_user_id(),'nama_user_generate'=>app_user_name()));$success++;}}
        tagihan_log_activity('Tambah Siswa Pembayar','Tagihan','Tambah','tagihan_siswa',$id,$m['kode_tagihan'],$success.' baris tagihan ditambahkan',null,array('siswa'=>$ids));return tagihan_transaction_result($success.' baris tagihan berhasil ditambahkan'.($skip?' dan '.$skip.' dilewati.':'.'));
    }
    public function keluarkan(){
        $id=(int)$this->input->post('id_tagihan');$sid=(int)$this->input->post('id_siswa');$m=$this->db->where('id',$id)->get('tagihan_master')->row_array();if(!$m)return model_response(false,'Tagihan tidak ditemukan.');if($this->db->where('id_tagihan_master',$id)->where('id_siswa',$sid)->where('nominal_dibayar >',0)->count_all_results('tagihan_siswa'))return model_response(false,'Siswa sudah memiliki pembayaran dan tidak dapat dikeluarkan.');$rows=$this->db->where('id_tagihan_master',$id)->where('id_siswa',$sid)->get('tagihan_siswa')->result_array();$this->db->trans_begin();$this->db->where('id_tagihan_master',$id)->where('id_siswa',$sid)->delete('tagihan_siswa');$this->db->where('id_tagihan_master',$id)->where('id_siswa',$sid)->update('tagihan_target_siswa',array('status'=>'Nonaktif'));tagihan_log_activity('Keluarkan Siswa Pembayar','Tagihan','Batal','tagihan_siswa',$sid,$m['kode_tagihan'],'Mengeluarkan siswa yang belum membayar',$rows,null);return tagihan_transaction_result('Siswa berhasil dikeluarkan dari tagihan.');
    }
}
