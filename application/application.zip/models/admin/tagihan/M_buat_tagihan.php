<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_buat_tagihan extends CI_Model
{
    public function periode_list(){return $this->db->order_by('id','DESC')->get('master_tahun_ajaran')->result_array();}
    public function jenis_list($tipe){return $this->db->where('status','Aktif')->where('tipe_default',$tipe)->order_by('nama_jenis')->get('tagihan_jenis')->result_array();}
    public function kelas_list(){return $this->db->select('ks.*,ta.periode')->from('kelas_setting ks')->join('master_tahun_ajaran ta','ta.id=CAST(ks.id_periode AS UNSIGNED)','left')->order_by('ta.id','DESC')->order_by('ks.nama_kelas')->get()->result_array();}
    public function cari_siswa(){
        $q=trim((string)$this->input->post('q',true));$idPeriode=(int)$this->input->post('id_periode');if(strlen($q)<2)return array();$like='%'.$q.'%';
        return $this->db->query("SELECT s.id,s.nis,s.nisn,s.nama_lengkap,k.id id_kelas_setting,k.id_kelas,k.nama_kelas,k.id_periode,ta.periode FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) LEFT JOIN master_tahun_ajaran ta ON ta.id=CAST(k.id_periode AS UNSIGNED) WHERE s.status_pendaftaran='Aktif' AND CAST(k.id_periode AS UNSIGNED)=? AND (s.nama_lengkap LIKE ? OR s.nis LIKE ? OR s.nisn LIKE ?) ORDER BY s.nama_lengkap LIMIT 30",array($idPeriode,$like,$like,$like))->result_array();
    }

    private function input_data($tipe){
        $idPeriode=(int)$this->input->post('id_periode');$idJenis=(int)$this->input->post('id_jenis_tagihan');$periode=$this->db->where('id',$idPeriode)->get('master_tahun_ajaran')->row_array();$jenis=$this->db->where('id',$idJenis)->where('status','Aktif')->get('tagihan_jenis')->row_array();if(!$periode||!$jenis)return array('error'=>'Tahun ajaran atau jenis tagihan tidak ditemukan.');if($jenis['tipe_default']!==$tipe)return array('error'=>'Jenis tagihan tidak sesuai tipe menu.');
        $nama=trim((string)$this->input->post('nama_tagihan',true));$target=trim((string)$this->input->post('target_tagihan',true));$tunggakan=$this->input->post('dianggap_tunggakan',true)==='Tidak'?'Tidak':'Ya';$nominal=nilai_nominal($this->input->post('nominal_default'));
        if($nama===''||$nominal<0||!in_array($target,array('Semua','Kelas','Siswa'),true))return array('error'=>'Nama tagihan, nominal, dan target wajib diisi dengan benar.');
        $kelas=$this->input->post('target_kelas');if(!is_array($kelas))$kelas=array();$siswa=$this->input->post('target_siswa');if(!is_array($siswa))$siswa=array();
        if($target==='Kelas'&&!$kelas)return array('error'=>'Pilih minimal satu kelas target.');if($target==='Siswa'&&!$siswa)return array('error'=>'Pilih minimal satu siswa target.');
        $periods=array();$parts=explode('/',$periode['periode']);$awal=(int)$parts[0];$akhir=isset($parts[1])?(int)$parts[1]:$awal+1;
        if($tipe==='Bulanan'){
            $months=$this->input->post('bulan');if(!is_array($months)||!$months)return array('error'=>'Pilih minimal satu bulan tagihan.');$tarif=$this->input->post('nominal_bulan');if(!is_array($tarif))$tarif=array();$jatuh=$this->input->post('jatuh_tempo_bulan');if(!is_array($jatuh))$jatuh=array();
            foreach($months as $m){$m=(int)$m;if($m<1||$m>12)continue;$year=$m>=7?$awal:$akhir;$val=isset($tarif[$m])?nilai_nominal($tarif[$m]):$nominal;if($val<=0)$val=$nominal;if($val<=0)return array('error'=>'Nominal setiap bulan terpilih harus lebih dari nol.');$periods[]=array('bulan'=>$m,'tahun'=>$year,'nama_bulan'=>nama_bulan($m),'nominal'=>$val,'jatuh_tempo'=>isset($jatuh[$m])?$jatuh[$m]:'');}
        }else{
            $month=(int)$this->input->post('bulan_penagihan');$year=(int)$this->input->post('tahun_penagihan');if($month<1||$month>12)$month=7;if(!$year)$year=$month>=7?$awal:$akhir;if($nominal<=0)return array('error'=>'Nominal tagihan harus lebih dari nol.');$periods[]=array('bulan'=>$month,'tahun'=>$year,'nama_bulan'=>nama_bulan($month),'nominal'=>$nominal,'jatuh_tempo'=>trim((string)$this->input->post('tanggal_jatuh_tempo',true)));
        }
        return array('periode'=>$periode,'jenis'=>$jenis,'nama'=>$nama,'target'=>$target,'tunggakan'=>$tunggakan,'nominal'=>$nominal,'kelas'=>array_map('intval',$kelas),'siswa'=>array_map('intval',$siswa),'periods'=>$periods,'keterangan'=>trim((string)$this->input->post('keterangan',true)),'model_tarif'=>$this->input->post('model_tarif_bulanan',true)==='Berbeda'?'Berbeda':'Sama');
    }

    private function target_students($data){
        $idPeriode=(int)$data['periode']['id'];$sql="SELECT DISTINCT s.id,s.nis,s.nisn,s.nama_lengkap,s.jk,k.id id_kelas_setting,k.id_kelas,k.nama_kelas,k.id_periode,ta.periode FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) LEFT JOIN master_tahun_ajaran ta ON ta.id=CAST(k.id_periode AS UNSIGNED) WHERE s.status_pendaftaran='Aktif' AND CAST(k.id_periode AS UNSIGNED)=?";$params=array($idPeriode);
        if($data['target']==='Kelas'){$sql.=" AND k.id IN (".implode(',',array_fill(0,count($data['kelas']),'?')).")";foreach($data['kelas'] as $v)$params[]=$v;}elseif($data['target']==='Siswa'){$sql.=" AND s.id IN (".implode(',',array_fill(0,count($data['siswa']),'?')).")";foreach($data['siswa'] as $v)$params[]=$v;}
        $sql.=" ORDER BY s.nama_lengkap";return $this->db->query($sql,$params)->result_array();
    }

    public function preview($tipe){
        $data=$this->input_data($tipe);if(isset($data['error']))return model_response(false,$data['error']);$students=$this->target_students($data);$total=0;foreach($data['periods'] as $p)$total+=count($students)*(float)$p['nominal'];return model_response(true,'Preview berhasil.',array('jumlah_siswa'=>count($students),'jumlah_baris'=>count($students)*count($data['periods']),'total_nominal'=>$total,'periods'=>$data['periods'],'students'=>array_slice($students,0,20)));
    }

    public function simpan($tipe){
        $data=$this->input_data($tipe);if(isset($data['error']))return model_response(false,$data['error']);$mode=$this->input->post('mode_simpan',true)==='Draft'?'Draft':'Terbitkan';$students=$this->target_students($data);if(!$students)return model_response(false,'Tidak ada siswa aktif pada target yang dipilih.');
        $kode=tagihan_next_code('TGH','tagihan_master','kode_tagihan');$first=$data['periods'][0];$last=end($data['periods']);reset($data['periods']);$audit=tagihan_audit_fields();$master=array_merge(array('kode_tagihan'=>$kode,'id_jenis_tagihan'=>(int)$data['jenis']['id'],'nama_jenis_tagihan'=>$data['jenis']['nama_jenis'],'nama_tagihan'=>$data['nama'],'tipe_tagihan'=>$tipe,'id_periode'=>(int)$data['periode']['id'],'periode'=>$data['periode']['periode'],'semester'=>null,'nominal_default'=>$data['nominal'],'model_tarif_bulanan'=>$data['model_tarif'],'bulan_mulai'=>$first['bulan'],'tahun_mulai'=>$first['tahun'],'bulan_selesai'=>$last['bulan'],'tahun_selesai'=>$last['tahun'],'bulan_penagihan'=>$first['bulan'],'tahun_penagihan'=>$first['tahun'],'tanggal_jatuh_tempo'=>$first['jatuh_tempo'],'target_tagihan'=>$data['target'],'dianggap_tunggakan'=>$data['tunggakan'],'status_generate'=>$mode==='Draft'?'Belum':'Selesai','status'=>$mode==='Draft'?'Draft':'Aktif','keterangan'=>$data['keterangan']),$audit);
        $this->db->trans_begin();$this->db->insert('tagihan_master',$master);$idMaster=$this->db->insert_id();
        foreach($data['periods'] as $p)$this->db->insert('tagihan_tarif_bulan',array_merge(array('id_tagihan_master'=>$idMaster,'bulan'=>$p['bulan'],'nama_bulan'=>$p['nama_bulan'],'tahun'=>$p['tahun'],'nominal'=>$p['nominal'],'tanggal_jatuh_tempo'=>$p['jatuh_tempo'],'status'=>'Aktif'),$audit));
        $classSeen=array();foreach($students as $s){if(!isset($classSeen[$s['id_kelas_setting']])){$this->db->insert('tagihan_target_kelas',array_merge(array('id_tagihan_master'=>$idMaster,'id_kelas_setting'=>(int)$s['id_kelas_setting'],'id_kelas'=>(int)$s['id_kelas'],'nama_kelas'=>$s['nama_kelas'],'id_periode'=>(int)$s['id_periode'],'periode'=>$s['periode'],'semester'=>null,'nominal_kelas'=>$data['nominal'],'status'=>'Aktif'),$audit));$classSeen[$s['id_kelas_setting']]=true;}
            if($data['target']==='Siswa')$this->db->insert('tagihan_target_siswa',array_merge(array('id_tagihan_master'=>$idMaster,'id_siswa'=>(int)$s['id'],'nis'=>$s['nis'],'nisn'=>$s['nisn'],'nama_siswa'=>$s['nama_lengkap'],'id_kelas_setting'=>(int)$s['id_kelas_setting'],'id_kelas'=>(int)$s['id_kelas'],'nama_kelas'=>$s['nama_kelas'],'nominal_target'=>$data['nominal'],'status'=>'Aktif'),$audit));}
        $generated=0;$skipped=0;if($mode!=='Draft'){foreach($students as $s){foreach($data['periods'] as $p){
            $this->db->from('tagihan_siswa')
                ->where('id_siswa',(int)$s['id'])
                ->where('id_jenis_tagihan',(int)$data['jenis']['id'])
                ->where('id_periode',(int)$data['periode']['id'])
                ->where('status_tagihan','Aktif');
            if($tipe==='Tahunan'){
                $this->db->where('tipe_tagihan','Tahunan');
            }elseif($tipe==='Bulanan'){
                $this->db->where('tipe_tagihan','Bulanan')
                    ->where('bulan',(int)$p['bulan'])
                    ->where('tahun',(int)$p['tahun']);
            }else{
                $this->db->where('id_tagihan_master',$idMaster)
                    ->where('bulan',(int)$p['bulan'])
                    ->where('tahun',(int)$p['tahun']);
            }
            $exists=$this->db->count_all_results();
            if($exists){$skipped++;continue;}
            $no=tagihan_next_code('TAG','tagihan_siswa','no_tagihan');$nom=(float)$p['nominal'];$this->db->insert('tagihan_siswa',array('no_tagihan'=>$no,'id_tagihan_master'=>$idMaster,'kode_tagihan'=>$kode,'id_jenis_tagihan'=>(int)$data['jenis']['id'],'nama_jenis_tagihan'=>$data['jenis']['nama_jenis'],'nama_tagihan'=>$data['nama'],'tipe_tagihan'=>$tipe,'id_periode'=>(int)$data['periode']['id'],'periode'=>$data['periode']['periode'],'semester'=>null,'bulan'=>$p['bulan'],'nama_bulan'=>$p['nama_bulan'],'tahun'=>$p['tahun'],'tanggal_jatuh_tempo'=>$p['jatuh_tempo'],'id_siswa'=>(int)$s['id'],'nis'=>$s['nis'],'nisn'=>$s['nisn'],'nama_siswa'=>$s['nama_lengkap'],'id_kelas_setting'=>(int)$s['id_kelas_setting'],'id_kelas'=>(int)$s['id_kelas'],'nama_kelas'=>$s['nama_kelas'],'nominal_awal'=>$nom,'jenis_keringanan'=>null,'nilai_keringanan'=>0,'nominal_tagihan'=>$nom,'nominal_dibayar'=>0,'sisa_tagihan'=>$nom,'dianggap_tunggakan'=>$data['tunggakan'],'status_pembayaran'=>'Belum Dibayar','status_tagihan'=>'Aktif','keterangan'=>$data['keterangan'],'tanggal_generate'=>tanggal_sekarang(),'waktu_generate'=>waktu_sekarang(),'id_user_generate'=>app_user_id(),'nama_user_generate'=>app_user_name()));$generated++;}}}
        tagihan_log_activity($mode==='Draft'?'Simpan Draft Tagihan':'Terbitkan Tagihan','Tagihan',$mode==='Draft'?'Tambah':'Tambah','tagihan_master',$idMaster,$kode,$data['nama'].' - '.$generated.' tagihan siswa',null,$master);$res=tagihan_transaction_result($mode==='Draft'?'Draft tagihan berhasil disimpan.':$generated.' tagihan siswa berhasil diterbitkan'.($skipped?' dan '.$skipped.' duplikat dilewati.':'.'));if($res['result']==='true')$res['id']=$idMaster;return $res;
    }
}
