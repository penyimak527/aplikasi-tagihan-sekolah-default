<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_daftar_tagihan extends CI_Model
{
    public function periode_list()
    {
        return $this->db->order_by('id', 'DESC')->get('master_tahun_ajaran')->result_array();
    }
    public function jenis_list()
    {
        return $this->db->order_by('nama_jenis')->get('tagihan_jenis')->result_array();
    }
    public function result()
    {
        $idPeriode = (int)$this->input->post('id_periode');
        $tipe = trim((string)$this->input->post('tipe', true));
        $jenis = (int)$this->input->post('id_jenis');
        $status = trim((string)$this->input->post('status', true));
        $search = trim((string)$this->input->post('search', true));
        $this->db->select("m.*, COUNT(DISTINCT ts.id_siswa) jumlah_siswa, COALESCE(SUM(ts.nominal_tagihan),0) total_nominal, SUM(CASE WHEN ts.status_pembayaran='Belum Dibayar' THEN 1 ELSE 0 END) belum_bayar, SUM(CASE WHEN ts.status_pembayaran='Dibayar Sebagian' THEN 1 ELSE 0 END) sebagian, SUM(CASE WHEN ts.status_pembayaran='Lunas' THEN 1 ELSE 0 END) lunas, SUM(CASE WHEN ts.status_pembayaran='Dibebaskan' THEN 1 ELSE 0 END) dibebaskan")->from('tagihan_master m')->join('tagihan_siswa ts', 'ts.id_tagihan_master=m.id', 'left')->group_by('m.id');
        if ($idPeriode) $this->db->where('m.id_periode', $idPeriode);
        if ($tipe !== '') $this->db->where('m.tipe_tagihan', $tipe);
        if ($jenis) $this->db->where('m.id_jenis_tagihan', $jenis);
        if ($status !== '') $this->db->where('m.status', $status);
        if ($search !== '') $this->db->group_start()->like('m.nama_tagihan', $search)->or_like('m.kode_tagihan', $search)->group_end();
        return $this->db->order_by('m.id', 'DESC')->get()->result_array();
    }
    public function detail()
    {
        $id = (int)$this->input->post('id');
        $master = $this->db->where('id', $id)->get('tagihan_master')->row_array();
        if (!$master) return array('result' => 'false', 'message' => 'Tagihan tidak ditemukan.');
        return array('result' => 'true', 'master' => $master, 'periods' => $this->db->where('id_tagihan_master', $id)->order_by('tahun')->order_by('bulan')->get('tagihan_tarif_bulan')->result_array(), 'classes' => $this->db->where('id_tagihan_master', $id)->get('tagihan_target_kelas')->result_array(), 'students' => $this->db->where('id_tagihan_master', $id)->limit(100)->get('tagihan_siswa')->result_array());
    }
    private function generate($master)
    {
        $id = (int)$master['id'];
        $periods = $this->db->where('id_tagihan_master', $id)->where('status', 'Aktif')->get('tagihan_tarif_bulan')->result_array();
        $classTargets = $this->db->where('id_tagihan_master', $id)->where('status', 'Aktif')->get('tagihan_target_kelas')->result_array();
        $studentTargets = $this->db->where('id_tagihan_master', $id)->where('status', 'Aktif')->get('tagihan_target_siswa')->result_array();
        $classIds = array_column($classTargets, 'id_kelas_setting');
        if ($master['target_tagihan'] === 'Siswa' && $studentTargets) {
            $ids = array_column($studentTargets, 'id_siswa');
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $students = $this->db->query("SELECT s.id,s.nis,s.nisn,s.nama_lengkap,k.id id_kelas_setting,k.id_kelas,k.nama_kelas,k.id_periode,ta.periode FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) LEFT JOIN master_tahun_ajaran ta ON ta.id=CAST(k.id_periode AS UNSIGNED) WHERE s.id IN ($placeholders) AND CAST(k.id_periode AS UNSIGNED)=?", array_merge($ids, array((int)$master['id_periode'])))->result_array();
        } else {
            if (!$classIds) return array(0, 0);
            $placeholders = implode(',', array_fill(0, count($classIds), '?'));
            $students = $this->db->query("SELECT DISTINCT s.id,s.nis,s.nisn,s.nama_lengkap,k.id id_kelas_setting,k.id_kelas,k.nama_kelas,k.id_periode,ta.periode FROM siswa s JOIN kelas_siswa ks ON CAST(ks.id_siswa AS UNSIGNED)=s.id AND ks.status_aktif='1' JOIN kelas_setting k ON k.id=CAST(ks.id_kelas_setting AS UNSIGNED) LEFT JOIN master_tahun_ajaran ta ON ta.id=CAST(k.id_periode AS UNSIGNED) WHERE k.id IN ($placeholders) AND s.status_pendaftaran='Aktif'", $classIds)->result_array();
        }
        $classMap = array();
        foreach ($classTargets as $x) $classMap[(int)$x['id_kelas_setting']] = $x;
        $studentMap = array();
        foreach ($studentTargets as $x) $studentMap[(int)$x['id_siswa']] = $x;
        $generated = 0;
        $skipped = 0;
        foreach ($students as $s) {
            foreach ($periods as $p) {
                if ($this->db->where('id_tagihan_master', $id)->where('id_siswa', (int)$s['id'])->where('bulan', (int)$p['bulan'])->where('tahun', (int)$p['tahun'])->count_all_results('tagihan_siswa')) {
                    $skipped++;
                    continue;
                }
                $nom = (float)$p['nominal'];
                if (isset($classMap[(int)$s['id_kelas_setting']]) && (float)$classMap[(int)$s['id_kelas_setting']]['nominal_kelas'] > 0) $nom = (float)$classMap[(int)$s['id_kelas_setting']]['nominal_kelas'];
                if (isset($studentMap[(int)$s['id']]) && (float)$studentMap[(int)$s['id']]['nominal_target'] > 0) $nom = (float)$studentMap[(int)$s['id']]['nominal_target'];
                $this->db->insert('tagihan_siswa', array('no_tagihan' => tagihan_next_code('TAG', 'tagihan_siswa', 'no_tagihan'), 'id_tagihan_master' => $id, 'kode_tagihan' => $master['kode_tagihan'], 'id_jenis_tagihan' => $master['id_jenis_tagihan'], 'nama_jenis_tagihan' => $master['nama_jenis_tagihan'], 'nama_tagihan' => $master['nama_tagihan'], 'tipe_tagihan' => $master['tipe_tagihan'], 'id_periode' => $master['id_periode'], 'periode' => $master['periode'], 'semester' => null, 'bulan' => $p['bulan'], 'nama_bulan' => $p['nama_bulan'], 'tahun' => $p['tahun'], 'tanggal_jatuh_tempo' => $p['tanggal_jatuh_tempo'], 'id_siswa' => $s['id'], 'nis' => $s['nis'], 'nisn' => $s['nisn'], 'nama_siswa' => $s['nama_lengkap'], 'id_kelas_setting' => $s['id_kelas_setting'], 'id_kelas' => $s['id_kelas'], 'nama_kelas' => $s['nama_kelas'], 'nominal_awal' => $nom, 'nilai_keringanan' => 0, 'nominal_tagihan' => $nom, 'nominal_dibayar' => 0, 'sisa_tagihan' => $nom, 'dianggap_tunggakan' => $master['dianggap_tunggakan'], 'status_pembayaran' => 'Belum Dibayar', 'status_tagihan' => 'Aktif', 'keterangan' => $master['keterangan'], 'tanggal_generate' => tanggal_sekarang(), 'waktu_generate' => waktu_sekarang(), 'id_user_generate' => app_user_id(), 'nama_user_generate' => app_user_name()));
                $generated++;
            }
        }
        return array($generated, $skipped);
    }
    public function terbitkan()
    {
        $id = (int)$this->input->post('id');
        $master = $this->db->where('id', $id)->get('tagihan_master')->row_array();
        if (!$master) return model_response(false, 'Tagihan tidak ditemukan.');
        if ($master['status'] !== 'Draft') return model_response(false, 'Hanya draft yang dapat diterbitkan.');
        $this->db->trans_begin();
        list($generated, $skipped) = $this->generate($master);
        if (!$generated && $skipped === 0) {
            $this->db->trans_rollback();
            return model_response(false, 'Tidak ada target siswa yang dapat dibuatkan tagihan.');
        }
        $this->db->where('id', $id)->update('tagihan_master', array('status' => 'Aktif', 'status_generate' => 'Selesai', 'tanggal_update' => tanggal_sekarang(), 'waktu_update' => waktu_sekarang(), 'id_user_update' => app_user_id(), 'nama_user_update' => app_user_name()));
        tagihan_log_activity('Terbitkan Draft Tagihan', 'Tagihan', 'Ubah', 'tagihan_master', $id, $master['kode_tagihan'], $generated . ' tagihan diterbitkan', $master, array('status' => 'Aktif'));
        return tagihan_transaction_result($generated . ' tagihan berhasil diterbitkan' . ($skipped ? ' dan ' . $skipped . ' duplikat dilewati.' : '.'));
    }
    public function batalkan_sisa()
    {
        $id = (int)$this->input->post('id');
        $alasan = trim((string)$this->input->post('alasan', true));
        if ($alasan === '') return model_response(false, 'Alasan pembatalan wajib diisi.');
        $master = $this->db->where('id', $id)->get('tagihan_master')->row_array();
        if (!$master) return model_response(false, 'Tagihan tidak ditemukan.');
        $rows = $this->db->where('id_tagihan_master', $id)->where('status_tagihan', 'Aktif')->where('sisa_tagihan >', 0)->get('tagihan_siswa')->result_array();
        $this->db->trans_begin();
        foreach ($rows as $r) {
            $this->db->where('id', $r['id'])->update('tagihan_siswa', array('sisa_tagihan' => 0, 'status_tagihan' => 'Dibatalkan', 'status_pembayaran' => 'Dibatalkan', 'keterangan' => trim($r['keterangan'] . ' | Dibatalkan: ' . $alasan), 'tanggal_update' => tanggal_sekarang(), 'waktu_update' => waktu_sekarang()));
        }
        $this->db->where('id', $id)->update('tagihan_master', array('status' => 'Dibatalkan', 'tanggal_update' => tanggal_sekarang(), 'waktu_update' => waktu_sekarang(), 'id_user_update' => app_user_id(), 'nama_user_update' => app_user_name()));
        tagihan_log_activity('Batalkan Sisa Tagihan', 'Tagihan', 'Batal', 'tagihan_master', $id, $master['kode_tagihan'], $alasan, $master, array('status' => 'Dibatalkan', 'jumlah' => count($rows)));
        return tagihan_transaction_result(count($rows) . ' sisa tagihan berhasil dibatalkan. Pembayaran yang sudah masuk tetap tersimpan.');
    }
}
