<?php
$format_rupiah = function ($nominal) {
    return 'Rp' . number_format((float) $nominal, 0, ',', '.'); };
?>
<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <title><?= html_escape($header['no_surat']) ?></title>
    <style>
        @page {
            size: A4;
            margin: 18mm
        }

        body {
            font: 14px 'Times New Roman', serif;
            line-height: 1.5;
            color: #111
        }

        .paper {
            max-width: 800px;
            margin: auto
        }

        .center {
            text-align: center
        }

        .right {
            text-align: right
        }

        .kop {
            border-bottom: 3px double #111;
            padding-bottom: 10px;
            margin-bottom: 20px
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0
        }

        th,
        td {
            border: 1px solid #444;
            padding: 6px
        }

        .signature {
            width: 45%;
            margin-left: auto;
            text-align: center;
            margin-top: 35px
        }

        .btn {
            padding: 9px 14px;
            background: #1266f1;
            color: #fff;
            border: 0;
            border-radius: 4px
        }

        @media print {
            .no-print {
                display: none
            }
        }
    </style>
</head>

<body>
    <div class="paper">
        <div class="kop center">
            <h2 style="margin:0"><?= html_escape(config_item('nama_sekolah') ?: 'SEKOLAH') ?></h2>
            <div>Surat Pemberitahuan Tunggakan</div>
        </div>
        <div class="right"><?= html_escape($header['tanggal_surat']) ?></div>
        <p>Nomor: <strong><?= html_escape($header['no_surat']) ?></strong></p>
        <p>Yth. Bapak/Ibu Orang Tua/Wali<br><strong><?= html_escape($header['nama_siswa']) ?></strong><br>Kelas
            <?= html_escape($header['nama_kelas']) ?></p>
        <p>Dengan hormat, berdasarkan catatan administrasi sekolah, terdapat tagihan wajib yang belum diselesaikan
            sebagai berikut:</p>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tagihan</th>
                    <th>Periode</th>
                    <th class="right">Nominal</th>
                    <th class="right">Dibayar</th>
                    <th class="right">Sisa</th>
                </tr>
            </thead>
            <tbody><?php foreach ($detail as $i => $d): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= html_escape($d['nama_tagihan']) ?></td>
                        <td><?= html_escape(($d['nama_bulan'] ?: '') . ' ' . $d['tahun']) ?></td>
                        <td class="right"><?= $format_rupiah($d['nominal_tagihan']) ?></td>
                        <td class="right"><?= $format_rupiah($d['nominal_dibayar']) ?></td>
                        <td class="right"><?= $format_rupiah($d['sisa_tagihan']) ?></td>
                    </tr><?php endforeach ?>
                <tr>
                    <th colspan="5" class="right">Total Tunggakan</th>
                    <th class="right"><?= $format_rupiah($header['total_tunggakan']) ?></th>
                </tr>
            </tbody>
        </table><?php if ($header['catatan_surat']): ?>
            <p><?= nl2br(html_escape($header['catatan_surat'])) ?></p><?php endif ?>
        <p>Demikian pemberitahuan ini kami sampaikan. Atas perhatian dan kerja sama Bapak/Ibu, kami mengucapkan terima
            kasih.</p>
        <div class="signature">
            <div><?= html_escape($header['jabatan_penandatangan']) ?></div>
            <div style="height:70px"></div><strong><u><?= html_escape($header['nama_penandatangan']) ?></u></strong>
        </div>
        <div class="center no-print" style="margin-top:30px"><button class="btn" onclick="window.print()">Cetak / Simpan
                PDF</button></div>
    </div>
</body>

</html>