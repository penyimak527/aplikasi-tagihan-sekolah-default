<div class="card">
    <div class="card-header border-bottom border-dashed">
        <h4 class="header-title mb-0">Langkah 1 - Informasi Tagihan</h4>
    </div>
    <div class="card-body">
        <form id="form_tagihan">
            <div class="row g-3">
                <div class="col-md-3"><label class="form-label">Tahun Ajaran</label><select name="id_periode" id="id_periode" class="form-select" required>
                        <option value="">Pilih tahun ajaran</option><?php foreach ($periode as $r): ?><option value="<?= $r['id'] ?>" data-periode="<?= html_escape($r['periode']) ?>"><?= html_escape($r['periode']) ?><?= $r['status'] === 'Aktif' ? ' - Aktif' : '' ?></option><?php endforeach; ?>
                    </select></div>
                <div class="col-md-3"><label class="form-label">Semester</label><select name="semester" id="semester" class="form-select">
                        <option value="">Semua Semester</option>
                        <option>Ganjil</option>
                        <option>Genap</option>
                    </select></div>
                <div class="col-md-3"><label class="form-label">Jenis Tagihan</label><select name="id_jenis_tagihan" id="id_jenis" class="form-select" required>
                        <option value="">Pilih jenis</option><?php foreach ($jenis as $r): ?><option value="<?= $r['id'] ?>" data-tunggakan="<?= $r['dianggap_tunggakan'] ?>"><?= html_escape($r['nama_jenis']) ?></option><?php endforeach; ?>
                    </select></div>
                <div class="col-md-3"><label class="form-label">Dihitung sebagai Tunggakan</label><select name="dianggap_tunggakan" id="dianggap_tunggakan" class="form-select">
                        <option>Ya</option>
                        <option>Tidak</option>
                    </select></div>
                <div class="col-md-8"><label class="form-label">Nama Tagihan</label><input name="nama_tagihan" class="form-control" placeholder="Nama tagihan" required></div>
                <div class="col-md-4"><label class="form-label">Nominal Umum</label><input name="nominal_default" id="nominal_default" type="text" inputmode="numeric" autocomplete="off" class="form-control money-input" required></div>
                <div class="col-12"><label class="form-label">Keterangan</label><textarea name="keterangan" class="form-control" rows="2"></textarea></div>
            </div>

            <div class="card border mt-4 mb-0">
                <div class="card-header border-bottom border-dashed">
                    <h4 class="header-title mb-0">Langkah 2 - <?= $tipe === 'Bulanan' ? 'Bulan dan Tarif' : 'Periode Penagihan' ?></h4>
                </div>
                <div class="card-body">
                    <?php if ($tipe === 'Bulanan'): ?>
                        <div class="row g-3 mb-3">
                            <div class="col-md-4"><label class="form-label">Mode Tarif</label><select name="model_tarif_bulanan" id="mode_tarif" class="form-select">
                                    <option value="Sama">Sama setiap bulan</option>
                                    <option value="Berbeda">Berbeda setiap bulan</option>
                                </select></div>
                            <div class="col-md-4 d-flex align-items-end"><button type="button" class="btn btn-outline-primary" id="terapkan_nominal">Terapkan Nominal Umum</button></div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle">
                                <thead>
                                    <tr>
                                        <th width="50">Pilih</th>
                                        <th>Bulan</th>
                                        <th>Tahun</th>
                                        <th>Nominal</th>
                                        <th>Jatuh Tempo</th>
                                    </tr>
                                </thead>
                                <tbody id="bulan_rows"><?php foreach (array(7, 8, 9, 10, 11, 12, 1, 2, 3, 4, 5, 6) as $m): ?><tr data-bulan="<?= $m ?>">
                                            <td><input type="checkbox" class="form-check-input cek_bulan" name="bulan[]" value="<?= $m ?>"></td>
                                            <td><?= nama_bulan($m) ?></td>
                                            <td class="tahun_label">-</td>
                                            <td><input type="text" inputmode="numeric" autocomplete="off" class="form-control form-control-sm money-input nominal_bulan" name="nominal_bulan[<?= $m ?>]" disabled></td>
                                            <td><input type="text" class="form-control form-control-sm jatuh_tempo" name="jatuh_tempo_bulan[<?= $m ?>]" disabled></td>
                                        </tr><?php endforeach; ?></tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="row g-3">
                            <div class="col-md-4"><label class="form-label"><?= $tipe === 'Tahunan' ? 'Bulan Mulai Tampil' : 'Bulan Tagihan' ?></label><select name="bulan_penagihan" id="bulan_penagihan" class="form-select"><?php foreach (range(1, 12) as $m): ?><option value="<?= $m ?>"><?= nama_bulan($m) ?></option><?php endforeach; ?></select></div>
                            <div class="col-md-4"><label class="form-label">Tahun</label><select name="tahun_penagihan" id="tahun_penagihan" class="form-select"></select></div>
                            <div class="col-md-4"><label class="form-label">Jatuh Tempo</label><input name="tanggal_jatuh_tempo" class="form-control tanggal"></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card border mt-4 mb-0">
                <div class="card-header border-bottom border-dashed">
                    <h4 class="header-title mb-0">Langkah 3 - Target Tagihan</h4>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4"><label class="form-label">Target</label><select name="target_tagihan" id="target_tagihan" class="form-select">
                                <option value="Semua">Semua Siswa Aktif</option>
                                <option value="Kelas">Kelas Tertentu</option>
                                <option value="Siswa">Siswa Tertentu</option>
                            </select></div>
                    </div>
                    <div id="target_kelas_area" class="mt-3 d-none"><label class="form-label">Pilih Kelas</label>
                        <div class="row g-2" id="kelas_options"><?php foreach ($kelas as $r): ?><div class="col-md-4 kelas-item" data-periode="<?= $r['id_periode'] ?>" data-semester="<?= html_escape($r['semester']) ?>"><label class="border rounded p-2 w-100"><input type="checkbox" class="form-check-input me-1" name="target_kelas[]" value="<?= $r['id'] ?>"> <?= html_escape($r['nama_kelas'] . ' - ' . $r['semester']) ?></label></div><?php endforeach; ?></div>
                    </div>
                    <div id="target_siswa_area" class="mt-3 d-none"><label class="form-label">Cari dan Tambahkan Siswa</label>
                        <div class="row g-2 align-items-end">
                            <div class="col-md-10"><input id="cari_siswa" class="form-control" placeholder="Nama/NIS/NISN"></div>
                            <div class="col-md-2 d-grid"><button type="button" class="btn btn-primary" id="btn_cari_siswa"><i class="ri-search-line me-1"></i>Cari</button></div>
                        </div>
                        <div id="hasil_siswa" class="mt-2"></div>
                        <div id="siswa_terpilih" class="mt-3 d-flex flex-wrap gap-2"></div>
                    </div>
                </div>
            </div>
            <div class="d-flex flex-wrap justify-content-end gap-2 mt-4"><button type="button" class="btn btn-light" onclick="document.getElementById('form_tagihan').reset();location.reload();">Reset</button><button type="button" class="btn btn-outline-secondary" onclick="simpan('Draft')">Simpan Draft</button><button type="button" class="btn btn-outline-primary" id="btn_preview">Preview Tagihan</button><button type="button" class="btn btn-primary" onclick="simpan('Terbitkan')">Buat Tagihan</button></div>
        </form>
    </div>
</div>
<div class="modal fade" id="modalPreview">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Preview Tagihan</h5><button class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="preview_content"></div>
            <div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Tutup</button><button class="btn btn-primary" onclick="simpan('Terbitkan')">Terbitkan Tagihan</button></div>
        </div>
    </div>
</div>
<script>
    var previewModal;
    var selectedStudents = {};
    $(function() {
        previewModal = new bootstrap.Modal('#modalPreview');
        flatpickr('.tanggal,.jatuh_tempo', {
            dateFormat: 'd-m-Y'
        });
        $('#id_periode,#semester').change(updatePeriodTarget);
        $('#id_jenis').change(function() {
            $('#dianggap_tunggakan').val($(this).find(':selected').data('tunggakan') || 'Ya');
        });
        $('#target_tagihan').change(toggleTarget);
        $('.cek_bulan').change(toggleMonth);
        $('#terapkan_nominal').click(applyNominal);
        $('#nominal_default').on('input', function() {
            if ($('#mode_tarif').val() === 'Sama') applyNominal();
        });
        $('#btn_cari_siswa').click(cariSiswa);
        $('#cari_siswa').keyup(function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                cariSiswa();
            }
        });
        $('#btn_preview').click(preview);
        toggleTarget();
        updatePeriodTarget();
    });

    function updatePeriodTarget() {
        var p = $('#id_periode').val(),
            sem = $('#semester').val(),
            period = $('#id_periode :selected').data('periode') || '';
        var years = String(period).split('/');
        $('#tahun_penagihan').html(years.map(function(y) {
            return '<option>' + escapeHtml(y) + '</option>';
        }).join(''));
        $('.kelas-item').each(function() {
            var ok = String($(this).data('periode')) === String(p) && (!sem || String($(this).data('semester')) === String(sem));
            $(this).toggle(ok);
            if (!ok) $(this).find('input').prop('checked', false);
        });
        $('#bulan_rows tr').each(function() {
            var m = Number($(this).data('bulan'));
            $(this).find('.tahun_label').text(m >= 7 ? (years[0] || '-') : (years[1] || '-'));
        });
        selectedStudents = {};
        renderSelected();
    }

    function toggleTarget() {
        var t = $('#target_tagihan').val();
        $('#target_kelas_area').toggleClass('d-none', t !== 'Kelas');
        $('#target_siswa_area').toggleClass('d-none', t !== 'Siswa');
    }

    function toggleMonth() {
        var tr = $(this).closest('tr'),
            on = this.checked;
        tr.find('input:not(.cek_bulan)').prop('disabled', !on);
        if (on && $('#mode_tarif').val() === 'Sama') tr.find('.nominal_bulan').val($('#nominal_default').val());
    }

    function applyNominal() {
        $('.cek_bulan:checked').each(function() {
            $(this).closest('tr').find('.nominal_bulan').val($('#nominal_default').val());
        });
    }

    function cariSiswa() {
        if (!$('#id_periode').val()) return Swal.fire('Perhatian', 'Pilih tahun ajaran terlebih dahulu.', 'warning');
        $.post('<?= base_url($endpoint . '/cari_siswa') ?>', {
            q: $('#cari_siswa').val(),
            id_periode: $('#id_periode').val(),
            semester: $('#semester').val()
        }, function(rows) {
            var h = '';
            if (!rows.length) h = '<div class="text-muted">Siswa tidak ditemukan.</div>';
            rows.forEach(function(r) {
                h += '<button type="button" class="btn btn-sm btn-outline-primary me-1 mb-1" onclick=\'addStudent(' + JSON.stringify(r) + ')\'>' + escapeHtml(r.nama_lengkap) + ' - ' + escapeHtml(r.nama_kelas) + '</button>';
            });
            $('#hasil_siswa').html(h);
        }, 'json').fail(ajaxError);
    }

    function addStudent(r) {
        selectedStudents[r.id] = r;
        renderSelected();
    }

    function removeStudent(id) {
        delete selectedStudents[id];
        renderSelected();
    }

    function renderSelected() {
        var h = '';
        Object.keys(selectedStudents).forEach(function(id) {
            var r = selectedStudents[id];
            h += '<span class="badge bg-primary-subtle text-primary p-2">' + escapeHtml(r.nama_lengkap) + ' <button type="button" class="btn-close btn-close-sm ms-1" onclick="removeStudent(' + id + ')"></button><input type="hidden" name="target_siswa[]" value="' + id + '"></span>';
        });
        $('#siswa_terpilih').html(h);
    }

    function formData(mode) {
        var data = serializeMoneyForm('#form_tagihan');
        return data + '&' + $.param({
            mode_simpan: mode
        });
    }

    function preview() {
        $('#btn_preview').prop('disabled', true);
        $.post('<?= base_url($endpoint . '/preview') ?>', formData('Preview'), function(r) {
            if (r.result !== 'true') return Swal.fire('Gagal', r.message, 'error');
            var h = '<div class="row g-3"><div class="col-md-4"><div class="alert alert-info"><small>Jumlah Siswa</small><h4>' + r.jumlah_siswa + '</h4></div></div><div class="col-md-4"><div class="alert alert-primary"><small>Jumlah Baris Tagihan</small><h4>' + r.jumlah_baris + '</h4></div></div><div class="col-md-4"><div class="alert alert-success"><small>Total Nominal</small><h4>' + formatRupiah(r.total_nominal) + '</h4></div></div></div><h6>Periode Tagihan</h6><ul>';
            r.periods.forEach(function(p) {
                h += '<li>' + escapeHtml(p.nama_bulan) + ' ' + p.tahun + ' - ' + formatRupiah(p.nominal) + '</li>';
            });
            h += '</ul><h6>Contoh Target</h6><div class="table-responsive"><table class="table table-sm"><thead><tr><th>Siswa</th><th>Kelas</th></tr></thead><tbody>';
            r.students.forEach(function(s) {
                h += '<tr><td>' + escapeHtml(s.nama_lengkap) + '</td><td>' + escapeHtml(s.nama_kelas) + '</td></tr>';
            });
            h += '</tbody></table></div>';
            $('#preview_content').html(h);
            previewModal.show();
        }, 'json').fail(ajaxError).always(function() {
            $('#btn_preview').prop('disabled', false);
        });
    }

    function simpan(mode) {
        confirmAction(mode === 'Draft' ? 'Simpan draft tagihan?' : 'Terbitkan tagihan?', 'Pastikan target dan tarif sudah benar.', function() {
            $('button').prop('disabled', true);
            $.post('<?= base_url($endpoint . '/simpan') ?>', formData(mode), function(r) {
                Swal.fire(r.result === 'true' ? 'Berhasil' : 'Gagal', r.message, r.result === 'true' ? 'success' : 'error').then(function() {
                    if (r.result === 'true') location.href = '<?= base_url('daftar_tagihan') ?>';
                });
            }, 'json').fail(ajaxError).always(function() {
                $('button').prop('disabled', false);
            });
        });
    }
</script>