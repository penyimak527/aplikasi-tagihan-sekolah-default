<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'login';
$route['wali_murid'] = 'wali_murid/login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
