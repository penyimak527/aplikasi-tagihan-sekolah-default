<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_pengaturan extends CI_Model
{
    public function format_list($jenis)
    {
        return $this->db->where('jenis_format', $jenis)->order_by("status_default='Ya'", 'DESC', false)->order_by('id', 'DESC')->get('tagihan_pengaturan_cetak')->result_array();
    }
    public function format_detail($id)
    {
        return $this->db->where('id', $id)->get('tagihan_pengaturan_cetak')->row_array();
    }
    public function format_save($jenis)
    {
        $id = (int)$this->input->post('id');
        $name = trim((string)$this->input->post('nama_format', true));
        if ($name === '') return model_response(false, 'Nama format wajib diisi.');
        $before = $id ? $this->format_detail($id) : null;
        $logo = $before['logo_sekolah'] ?? '';
        if (!empty($_FILES['logo']['name'])) {
            $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, array('png', 'jpg', 'jpeg', 'webp'), true)) return model_response(false, 'Logo hanya boleh PNG, JPG, JPEG, atau WEBP.');
            $dir = FCPATH . 'uploads/pengaturan/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $file = 'logo_' . date('YmdHis') . '_' . mt_rand(100, 999) . '.' . $ext;
            if (!move_uploaded_file($_FILES['logo']['tmp_name'], $dir . $file)) return model_response(false, 'Upload logo gagal.');
            $logo = 'uploads/pengaturan/' . $file;
        }
        $json = $this->input->post('pengaturan_json', false);
        if (is_array($json)) $json = json_encode($json, JSON_UNESCAPED_UNICODE);
        if (is_string($json) && $json !== '' && json_decode($json, true) === null) return model_response(false, 'Pengaturan khusus harus berupa JSON yang valid.');
        $default = $this->input->post('status_default') === 'Ya' ? 'Ya' : 'Tidak';
        $status = $this->input->post('status', true) === 'Tidak Aktif' ? 'Tidak Aktif' : 'Aktif';
        if ($default === 'Ya') $status = 'Aktif';
        $data = array('jenis_format' => $jenis, 'nama_format' => $name, 'status_default' => $default, 'ukuran_kertas' => trim((string)$this->input->post('ukuran_kertas', true)), 'orientasi' => trim((string)$this->input->post('orientasi', true)) ?: 'Portrait', 'lebar_kertas' => trim((string)$this->input->post('lebar_kertas', true)), 'tinggi_kertas' => trim((string)$this->input->post('tinggi_kertas', true)), 'margin_atas' => trim((string)$this->input->post('margin_atas', true)), 'margin_bawah' => trim((string)$this->input->post('margin_bawah', true)), 'margin_kiri' => trim((string)$this->input->post('margin_kiri', true)), 'margin_kanan' => trim((string)$this->input->post('margin_kanan', true)), 'tampilkan_logo' => $this->input->post('tampilkan_logo') === 'Tidak' ? 'Tidak' : 'Ya', 'logo_sekolah' => $logo, 'nama_sekolah' => trim((string)$this->input->post('nama_sekolah', true)), 'alamat_sekolah' => trim((string)$this->input->post('alamat_sekolah', true)), 'telepon_sekolah' => trim((string)$this->input->post('telepon_sekolah', true)), 'judul_bukti' => trim((string)$this->input->post('judul_bukti', true)), 'header_cetak' => trim((string)$this->input->post('header_cetak', false)), 'footer_cetak' => trim((string)$this->input->post('footer_cetak', false)), 'tampilkan_terbilang' => $this->input->post('tampilkan_terbilang') === 'Tidak' ? 'Tidak' : 'Ya', 'tampilkan_uang_diterima' => $this->input->post('tampilkan_uang_diterima') === 'Tidak' ? 'Tidak' : 'Ya', 'tampilkan_kembalian' => $this->input->post('tampilkan_kembalian') === 'Tidak' ? 'Tidak' : 'Ya', 'tampilkan_sisa_tagihan' => $this->input->post('tampilkan_sisa_tagihan') === 'Tidak' ? 'Tidak' : 'Ya', 'nama_penandatangan' => trim((string)$this->input->post('nama_penandatangan', true)), 'jabatan_penandatangan' => trim((string)$this->input->post('jabatan_penandatangan', true)), 'posisi_tanda_tangan' => trim((string)$this->input->post('posisi_tanda_tangan', true)) ?: 'Kanan', 'pengaturan_json' => $json, 'status' => $status);
        $this->db->trans_begin();
        if ($data['status_default'] === 'Ya') $this->db->where('jenis_format', $jenis)->update('tagihan_pengaturan_cetak', array('status_default' => 'Tidak'));
        if ($id) {
            $this->db->where('id', $id)->update('tagihan_pengaturan_cetak', $data);
        } else {
            $data = array_merge($data, tagihan_audit_fields());
            $this->db->insert('tagihan_pengaturan_cetak', $data);
            $id = $this->db->insert_id();
        }
        tagihan_log_activity(($before ? 'Ubah' : 'Tambah') . ' Format ' . $jenis, 'Pengaturan', $before ? 'Ubah' : 'Tambah', 'tagihan_pengaturan_cetak', $id, $name, 'Konfigurasi format ' . $jenis, $before, $data);
        return tagihan_transaction_result('Pengaturan format berhasil disimpan.');
    }
    public function set_default()
    {
        $id = (int)$this->input->post('id');
        $r = $this->format_detail($id);
        if (!$r) return model_response(false, 'Format tidak ditemukan.');
        $this->db->trans_begin();
        $this->db->where('jenis_format', $r['jenis_format'])->update('tagihan_pengaturan_cetak', array('status_default' => 'Tidak'));
        $this->db->where('id', $id)->update('tagihan_pengaturan_cetak', array('status_default' => 'Ya', 'status' => 'Aktif'));
        tagihan_log_activity('Jadikan Format Default', 'Pengaturan', 'Ubah', 'tagihan_pengaturan_cetak', $id, $r['nama_format'], 'Format default ' . $r['jenis_format'], $r, array('status_default' => 'Ya'));
        return tagihan_transaction_result('Format berhasil dijadikan default.');
    }
    public function template_list()
    {
        return $this->db->order_by('jenis_template')->order_by("status_default='Ya'", 'DESC', false)->order_by('id', 'DESC')->get('tagihan_template_whatsapp')->result_array();
    }
    public function template_save()
    {
        $id = (int)$this->input->post('id');
        $jenis = trim((string)$this->input->post('jenis_template', true));
        $nama = trim((string)$this->input->post('nama_template', true));
        $isi = trim((string)$this->input->post('isi_template', false));
        $default = $this->input->post('status_default') === 'Ya' ? 'Ya' : 'Tidak';
        $status = $this->input->post('status', true) === 'Tidak Aktif' ? 'Tidak Aktif' : 'Aktif';
        if ($default === 'Ya') $status = 'Aktif';
        if (!in_array($jenis, array('Bukti Pembayaran', 'Surat Tunggakan'), true) || $nama === '' || $isi === '') return model_response(false, 'Jenis, nama, dan isi template wajib diisi.');
        preg_match_all('/\{[^}]+\}/', $isi, $m);
        $allowed = array('{nama_wali}', '{nama_siswa}', '{kelas}', '{tanggal}', '{no_transaksi}', '{total_bayar}', '{total_tunggakan}', '{nama_sekolah}', '{nama_petugas}');
        $unknown = array_diff(array_unique($m[0]), $allowed);
        if ($unknown) return model_response(false, 'Variabel tidak dikenal: ' . implode(', ', $unknown));
        $before = $id ? $this->db->where('id', $id)->get('tagihan_template_whatsapp')->row_array() : null;
        $data = array('jenis_template' => $jenis, 'nama_template' => $nama, 'isi_template' => $isi, 'status_default' => $default, 'status' => $status);
        $this->db->trans_begin();
        if ($default === 'Ya') $this->db->where('jenis_template', $jenis)->update('tagihan_template_whatsapp', array('status_default' => 'Tidak'));
        if ($id) $this->db->where('id', $id)->update('tagihan_template_whatsapp', $data);
        else {
            $data = array_merge($data, tagihan_audit_fields());
            $this->db->insert('tagihan_template_whatsapp', $data);
            $id = $this->db->insert_id();
        }
        tagihan_log_activity(($before ? 'Ubah' : 'Tambah') . ' Template WhatsApp', 'Pengaturan', $before ? 'Ubah' : 'Tambah', 'tagihan_template_whatsapp', $id, $nama, 'Template ' . $jenis, $before, $data);
        return tagihan_transaction_result('Template WhatsApp berhasil disimpan.');
    }
    public function template_default()
    {
        $id = (int)$this->input->post('id');
        $r = $this->db->where('id', $id)->get('tagihan_template_whatsapp')->row_array();
        if (!$r) return model_response(false, 'Template tidak ditemukan.');
        $this->db->trans_begin();
        $this->db->where('jenis_template', $r['jenis_template'])->update('tagihan_template_whatsapp', array('status_default' => 'Tidak'));
        $this->db->where('id', $id)->update('tagihan_template_whatsapp', array('status_default' => 'Ya', 'status' => 'Aktif'));
        tagihan_log_activity('Jadikan Template Default', 'Pengaturan', 'Ubah', 'tagihan_template_whatsapp', $id, $r['nama_template'], 'Template default ' . $r['jenis_template']);
        return tagihan_transaction_result('Template berhasil dijadikan default.');
    }
    public function logs()
    {
        $awal = trim((string)$this->input->post_get('awal', true));
        $akhir = trim((string)$this->input->post_get('akhir', true));
        $user = trim((string)$this->input->post_get('user', true));
        $aksi = trim((string)$this->input->post_get('aksi', true));
        $modul = trim((string)$this->input->post_get('modul', true));
        $q = trim((string)$this->input->post_get('q', true));
        $this->db->from('tagihan_log_aktivitas');
        if ($awal) $this->db->where("STR_TO_DATE(tanggal,'%d-%m-%Y') >=", date('Y-m-d', strtotime(str_replace('/', '-', $awal))));
        if ($akhir) $this->db->where("STR_TO_DATE(tanggal,'%d-%m-%Y') <=", date('Y-m-d', strtotime(str_replace('/', '-', $akhir))));
        if ($user) $this->db->like('nama_user', $user);
        if ($aksi) $this->db->where('aksi', $aksi);
        if ($modul) $this->db->where('modul', $modul);
        if ($q) $this->db->group_start()->like('nomor_referensi', $q)->or_like('keterangan', $q)->or_like('jenis_aktivitas', $q)->group_end();
        return $this->db->order_by('id', 'DESC')->limit(1000)->get()->result_array();
    }
    public function log_detail($id)
    {
        return $this->db->where('id', $id)->get('tagihan_log_aktivitas')->row_array();
    }
    public function export_logs()
    {
        $rows = $this->logs();
        $name = 'log_aktivitas_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        // UTF-8 BOM agar karakter terbaca dengan benar di Excel.
        echo "\xEF\xBB\xBF";

        /*
         * Memaksa Microsoft Excel menggunakan titik koma sebagai delimiter.
         * Tanpa baris ini, pada beberapa pengaturan regional Excel seluruh
         * isi CSV dapat terbaca sebagai satu kolom.
         */
        echo "sep=;\r\n";

        $o = fopen('php://output', 'w');

        fputcsv($o, array(
            'Tanggal',
            'Waktu',
            'Pengguna',
            'Aktivitas',
            'Modul',
            'Aksi',
            'Referensi',
            'Keterangan',
            'IP'
        ), ';');

        foreach ($rows as $r) {
            fputcsv($o, array(
                isset($r['tanggal']) ? $r['tanggal'] : '',
                isset($r['waktu']) ? $r['waktu'] : '',
                isset($r['nama_user']) ? $r['nama_user'] : '',
                isset($r['jenis_aktivitas']) ? $r['jenis_aktivitas'] : '',
                isset($r['modul']) ? $r['modul'] : '',
                isset($r['aksi']) ? $r['aksi'] : '',
                isset($r['nomor_referensi']) ? $r['nomor_referensi'] : '',
                isset($r['keterangan']) ? $r['keterangan'] : '',
                isset($r['ip_address']) ? $r['ip_address'] : ''
            ), ';');
        }

        fclose($o);
        exit;
    }
}